<?php 

include "../../connect.php";
include "session.php";
$t=$_GET['t'];
$id=$_GET['id'];
if($t==0)
{  
$query = "DELETE from admin where id='$id'";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Deleted successfully!');javascript:history.back();</script>";
	
   }
     else{
          echo "<script type='text/javascript'>alert('Failed to Delete!');javascript:history.back();</script>";
        } 
      

}
if($t==1)
{  
$query = "DELETE from slider where id='$id'";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Deleted successfully!');javascript:history.back();</script>";

   }
     else{
          echo "<script type='text/javascript'>alert('Failed to Delete!');javascript:history.back();</script>";
        } 
      

}
if($t==2)
{  
$query = "DELETE from menu where id='$id'";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Deleted successfully!');javascript:history.back();</script>";
	
   }
     else{
          echo "<script type='text/javascript'>alert('Failed to Delete!');javascript:history.back();</script>";
        } 
      

}
if($t==3)
{  
$query = "DELETE from gallery where id='$id'";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Deleted successfully!');javascript:history.back();</script>";
	
   }
     else{
          echo "<script type='text/javascript'>alert('Failed to Delete!');javascript:history.back();</script>";
        } 
      

}
if($t==4)
{  
$query = "DELETE from peoplesay where id='$id'";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Deleted successfully!');javascript:history.back();</script>";

   }
     else{
          echo "<script type='text/javascript'>alert('Failed to Delete!');javascript:history.back();</script>";
        } 
      

}









?>

