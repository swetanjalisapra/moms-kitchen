<?php 
include "../../connect.php";

include "header.php";
if(isset($_POST['submit']))
{
	$nm=mysqli_real_escape_string($conn, $_POST['name']);
		
	$des=mysqli_real_escape_string($conn, $_POST['des']);
	$per=mysqli_real_escape_string($conn, $_POST['per']);
	$query = "INSERT INTO coupon (name,des,per) 
					  VALUES('$nm','$des','$per')";
		$sql=mysqli_query($conn, $query);
	  if($sql==true){
    echo  "<script type='text/javascript'>alert('Uploaded successfully!');</script>";
   }
     else{
          echo "<script type='text/javascript'>alert('Failed to upload!');javascript:history.back();</script>";
        } 
      echo '<META HTTP-EQUIV="refresh" content="0;URL="coupon.php">';
	
	
	
	}





?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->


<body>
    <div class="wrapper">
        <!-- Sidebar Holder -->
        

        <!-- Page Content Holder -->
        <div id="content">
            <!-- top-bar -->
         
            <!--// top-bar -->

            <!-- main-heading -->
         
            <!--// main-heading -->   <div class="col-md-8 ">
<form style="align-content:center;"  action="coupon.php" method="post" enctype="multipart/form-data" >
       
         <br>
        
         <div class="form-group">
            <label for="heading">Name</label>
            <input type="text" class="form-control" id="heading" name="name" placeholder="Enter Name" required="">
         </div>
         <div class="form-group">
            <label for="price">Quantity</label>
            <input type="text" class="form-control" id="price" name="des" placeholder="Enter quantity" required="">
         </div>
         <div class="form-group">
            <label for="cut price">Measure</label>
            <input type="text" class="form-control" id="cutprice" name="per" placeholder="Enter & or Rs">
            <!--  <textarea type="text" rows="5" class="form-control" id="paragraph" name="content" placeholder="Write Something..."></textarea> -->
         </div>
         
         
         <div class="card-footer">
            <button type="submit" name="submit" class="btn btn-primary btn-sm">
            <i class="fa fa-dot-circle-o"></i> Submit
            </button>
			 
            <button type="reset" class="btn btn-danger btn-sm">
            <i class="fa fa-ban"></i> Reset
            </button>
         </div>
      </form>
	  </div>
	   <br> &nbsp;&nbsp;&nbsp;&nbsp;<a href="menu.php"><button class="btn btn-primary btn-sm"><i class="fa fa-dot-circle-o"></i>Back to Menu </button></a>

 <div class="row">
         <div class="col-md-12">
		 <br><br><br>
		 <hr>
            <div class="card">
               <div class="card-header">
                  <strong class="card-title">Data Table</strong>
               </div>
               <div class="card-body">
                  <table id="bootstrap-data-table" class="table table-striped table-bordered">
                     <thead>
                        <tr>
						 <th>ID</th>
                           <th>Name</th>
						  <th>Description</th>
<th>Delete</th>
                          
                        </tr>
                     </thead>
                     <tbody>
                        <?php 
                           $result2 = mysqli_query($conn," SELECT * FROM `coupon` ") or die( mysqli_error($conn) );
                           while ($row2 = mysqli_fetch_array($result2)) {
                           ?>
                        <tr>
						<td>
                              <?php echo "<p>".$row2['id']."</p>"; ?>
                           </td>
						   <td>
                              <?php echo "<p>".$row2['name']."</p>"; ?>
                           </td>
						   
						  <td>
                              <?php echo "<p>".$row2['des']."".$row2['per']."</p>"; ?>
                           </td>
                        	
                           
                          
                           <td>
                              <?php  echo "<a class='img11 delete' data-confirm='Are you sure to delete this item?' href=delete.php?t=5&id=".$row2['id']."> <i class='fa fa-trash' style='font-size:24px; color:red;' title='Delete'></i></a><br>";?>

          </td>
                        </tr>
                        <?php  }
                           ?>
                     </tbody>
                  </table>
               </div>
            </div>
         
      </div>

  
            <!--// Cards Header & Footer -->
           
            <!--// Cards Header & Footer -->

            <!--// Cards content -->

            <!--// Copyright -->
        </div>
    </div>

<script type="text/javascript">
  var deleteLinks = document.querySelectorAll('.delete');

for (var i = 0; i < deleteLinks.length; i++) {
  deleteLinks[i].addEventListener('click', function(event) {
    event.preventDefault();

    var choice = confirm(this.getAttribute('data-confirm'));

    if (choice) {
      window.location.href = this.getAttribute('href');
    }
  });
}
</script>
    <!-- Required common Js -->
    <script src='js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

    <!-- Sidebar-nav Js -->
    <script>
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
    <!--// Sidebar-nav Js -->

    <!-- dropdown nav -->
    <script>
        $(document).ready(function () {
            $(".dropdown").hover(
                function () {
                    $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                    $(this).toggleClass('open');
                },
                function () {
                    $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                    $(this).toggleClass('open');
                }
            );
        });
    </script>
    <!-- //dropdown nav -->

    <!-- Js for bootstrap working-->
    <script src="js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->
<!--Dropdown Script Start-->
<script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/main.js"></script>
<!--Dropdown Script End-->
<script src="assets/js/lib/data-table/datatables.min.js"></script>
<script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="assets/js/lib/data-table/jszip.min.js"></script>
<script src="assets/js/lib/data-table/pdfmake.min.js"></script>
<script src="assets/js/lib/data-table/vfs_fonts.js"></script>
<script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="assets/js/lib/data-table/buttons.print.min.js"></script>
<script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="assets/js/lib/data-table/datatables-init.js"></script>
<script type="text/javascript">
   $(document).ready(function() {
     $('#bootstrap-data-table-export').DataTable();
   } );
</script>
</body>

</html>